---
name: dsa-visualizer
description: Generate clean, light-themed, pedagogically sequenced SVG diagrams for Data Structures & Algorithms concepts — arrays, linked lists, trees, graphs, sorting, searching, DP, two-pointer, sliding window, backtracking, heaps, and more. Use whenever the user asks to visualize, draw, diagram, or trace through a DSA topic or algorithm.
---

# DSA Visualizer

Generates single self-contained SVG diagrams via `visualize:show_widget`, following a fixed visual
design system so every diagram — regardless of algorithm — looks like it came from the same tool.

This file was rebuilt from a forensic analysis of 10 real generated outputs (counting sort,
Floyd–Warshall, Kruskal's MST, matrix chain DP, Floyd's cycle detection, monotonic stack, Dijkstra,
N-ary tree diameter, min-time-to-collect-apples, two-pointer subsequence check). Every value below
(colors, sizes, spacing) was measured directly from those files, not reconstructed from memory.

## Mandatory workflow

1. Call `visualize:read_me` with `modules=['diagram']` once per session before the first `show_widget` call.
2. Write a Python generator script that precomputes ALL coordinates before touching any SVG string.
   Never hand-place coordinates ad hoc — crowding and overlap bugs come from skipping this.
3. Validate programmatically before rendering (see Quality Checklist) — grep for malformed tags,
   unclosed brackets in labels (`s[0]` not `s[0`), and text that would overflow its shape.
4. Render via `visualize:show_widget`. Read the file back if it was written to disk first — never
   transcribe SVG content by hand into the tool call.
5. Complexity should scale up across a session — if the last example had 7 nodes, the next should be
   noticeably bigger, not a trivial re-skin.

## Canvas & structure (non-negotiable)

- `viewBox="0 0 680 H"` — width is **always exactly 680**. Every one of the 10 reference files uses
  this, from a 700px-tall counting-sort trace to a 3912px-tall apple-collection trace. **Height is the
  only dimension that scales.** Widening the viewBox shrinks every element proportionally and makes
  text illegible — never do it, no matter how crowded a row looks. Solve crowding by adding height
  (more vertical room between rows, or splitting into more rows), never by widening.
- Root: `<svg width="100%" viewBox="0 0 680 H" role="img" xmlns="http://www.w3.org/2000/svg">`
- Include a `<title>` (short) and `<desc>` (one sentence describing the phase structure / arrow rule)
  right after the opening tag — every reference file does this.
- Standard arrowhead marker, define once in `<defs>`:
  ```xml
  <marker id="arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
    <path d="M2 1L8 5L2 9" fill="none" stroke="context-stroke" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  </marker>
  ```
- **Cross-phase arrows only connect consecutive states.** Never draw an arrow that skips a row or
  jumps back more than one step — this was an explicit design rule in the counting-sort reference
  (`desc`: "simple down-arrows between consecutive states only. No crossing arrows.").
- Background: white/off-white only. No dark fills anywhere in the canvas.

## Typography

Font family everywhere: `"Anthropic Sans", -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif`

Measured sizes/weights, used consistently by role:

| Role | Size | Weight |
|---|---|---|
| Section/phase heading (inside header rect) | 14px | 500 |
| Body values, cell contents, labels | 12px | 400 |
| Small annotations, footnotes, index labels | 11px | 400–500 |
| Rare strong emphasis callout | 12px | 600 |

Text width estimate for sizing shapes: ~7px/char at 12px, ~7.8px/char at 14px bold. Always compute
this in the generator script before setting a rect's width — never eyeball it.

## Color system

Every semantic color is a **pastel fill + saturated stroke of the same hue**, with an even darker
variant of the stroke hue reserved for text drawn on top of that fill. These are the exact values
measured across the reference set — use them verbatim, don't invent new hexes.

| Name | Fill (light bg) | Stroke (border) | Text-on-fill (dark) | Typical use |
|---|---|---|---|---|
| `c-blue` | `#E6F1FB` | `#185FA5` | `#0C447C` | headings, primary structure, "current" pointer |
| `c-green` | `#EAF3DE` | `#3B6D11` | `#27500A` | sorted/finalized/success state |
| `c-teal` | `#E1F5EE` | `#0F6E56` | `#085041` | secondary structure (queues, visited sets) |
| `c-amber` | `#FAEEDA` | `#854F0B` | `#633806` | in-progress / comparison / "current" cell |
| `c-gray` | `#F1EFE8` | `#5F5E5A` | `#444440` | neutral/default/unvisited cells |
| `c-purple` | `#EEEDFE` | `#534AB7` | `#3C3489` | auxiliary data structure (stack, recursion depth) |
| `c-pink` | `#FBEAF0` | `#99355B` | `#7A2A48` | eliminated / losing option / backtracked |
| `c-red` | `#FCEBEB` | `#A32D2D` | `#791F1F` | conflict, cycle detected, invalid/rejected |

Rounded-rect corner radius by role: `rx=2` for small array/table cells, `rx=4–6` for medium boxes/nodes,
`rx=8` for section headers and title bars. These are the only rx values used across all 10 references —
don't introduce arbitrary radii.

Line/stroke weight: `0.5px` for filled rect borders, `1.5px` for arrows and connecting lines.

## Layout rules

- **Steps are line-wise.** Each algorithm step/state occupies its own horizontal band, top to bottom.
  Measured row-to-row spacing is **~72–96px** when a row contains a labeled structure (stack/queue/table),
  and tighter (~50–65px) for simple annotation-only rows. Pick the spacing that fits the row's content,
  computed from actual text/shape heights — don't hardcode one number for every diagram.
- Only phase/section headers get the rounded-rect title-bar treatment (`c-blue` fill, `rx=8`, ~38px tall
  for the main title, ~30px for subsection headers like "Pass 1"). Step rows themselves are NOT boxed —
  data structure cells (array slots, stack frames, table cells) are boxed individually with `rx=2–6`.
- **Every data structure instance must be explicitly named on-canvas** — e.g. "stack S", "queue Q
  (front → back)", "dist[]", "count[]" — not just implied by shape.
- **Recurring elements repeat in every row where they're relevant.** If a stack/queue/priority-queue
  changes every step, redraw its current state in every row, not just at the end.
- **Array/index labels always include both brackets**: `s[0]`, `l[3]`, `r[7]`. When generating labels
  programmatically, always append the closing `]` explicitly — a truncated `s[0` is a hard failure.
  Verify this with a regex pass before rendering.
- **DP tables**: show the grid filling incrementally; highlight the current cell (`c-amber`) and the
  cells it depends on (`c-blue`). Where a choice is made (e.g. matrix chain split point, interval DP
  cut point), show the **losing options** alongside the winner — dim/gray them (`c-gray` or `c-pink`),
  don't just show the final winning value.
- **Graphs**: fixed node positions across all frames of the same graph — never re-layout nodes between
  steps. Highlight the relaxed/active edge in `c-amber`; show the running `dist[]`/`parent[]` table
  inline next to the graph on the same row.
- **Trees**: top-down hierarchy, consistent level gaps, no edge crossings. Color nodes by state:
  unvisited `c-gray`, current `c-amber`, visited `c-green`, backtracked `c-pink`.
- **Linked lists / cycle detection**: draw nodes left-to-right with pointer arrows; if a cycle exists,
  the cycle-closing arrow must be redrawn in every row from the point it's introduced onward — it's a
  "recurring element" per the rule above, not a one-time annotation.
- **Monotonic stack / deque**: draw the stack vertically or horizontally with clear top/front labeling,
  and show pushes/pops explicitly each row (element entering in `c-amber`, popped elements shown briefly
  in `c-pink` before removal).
- **Two-pointer / sliding window**: show both pointers labeled inline on the array each row; shade the
  active window range in `c-amber` or `c-teal`.
- **First occurrence vs repeat steps**: give full explanatory detail (what happened and why) the first
  time a step pattern occurs; compress later repeats of the same pattern to a short label so the
  diagram doesn't get bloated with redundant prose.

## Quality checklist (verify programmatically before `show_widget`)

- [ ] `viewBox="0 0 680 H"` — width is exactly 680, no exceptions
- [ ] No unclosed brackets in any index label (regex: every `[` has a matching `]` before the next `<`)
- [ ] Every fill/stroke pair used is one of the 8 defined semantic colors (no ad hoc hexes)
- [ ] Every data structure instance is named in text somewhere on canvas
- [ ] Recurring structures (stack/queue/PQ/cycle arrow) appear in every relevant row, not just once
- [ ] Cross-phase arrows connect only consecutive rows/states — none skip or jump backward
- [ ] Text never overflows its containing shape — width computed from char count, not guessed
- [ ] Font sizes are only 11/12/14px, weights only 400/500/600, per the role table above
- [ ] rx values are only 2, 4, 5, 6, or 8, matching role (cells vs headers)
- [ ] DP/greedy diagrams show losing options, not just the winning path
- [ ] Complexity of this example is scaled up from the previous one in the session, where applicable

## Reference examples

Real validated outputs ship in `references/`, next to this SKILL.md (resolve relative to wherever this
file was loaded from — never hardcode an absolute path). Before building a new diagram, `view` the
closest-matching file there (convert to PNG first — `view` won't render `.svg` directly) and copy its
layout/color/spacing decisions directly instead of re-deriving them from the rules above. Matching a
reference and lifting its structure is far cheaper than reasoning a new layout from scratch.

## Output format

Single self-contained SVG, rendered via `visualize:show_widget`:

```
Title bar (c-blue, rx=8, ~38px tall)
  ↓
Phase/section header (rx=6-8, colored by phase meaning)
  Step rows (line-wise, data structure state inline, vars inline)
  ↓ (consecutive-only arrows)
  ...
  ↓
Final State header (c-green)
  Final data structure snapshot
```
